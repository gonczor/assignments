#include <stdio.h>
#include <time.h>
#include "tasks.h"

int main(void)
{
    srand(time(NULL));
    //task1();
    //task2();
    //task3();
    //task5();
    //task6();
    //task7();
    //task8();
    //task9();
    //task10();
    task12();
    return 0;
}

