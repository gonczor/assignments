#include <stdio.h>
#include "tasks.h"

int main(void)
{
    printf("Hello World!\n");
    printf("%.2lf\n", task1());
    printf("%.2lf\n", task2());
    printf("%.2lf\n", task3());
    printf("%.2lf\n", task4());
    printf("%.2lf\n", task5());
    printf("%s\n", task6());
    printf("%s\n", task7());
    printf("%s\n", task8());
    printf("%s\n", task9());
    printf("%s\n", task10());
    printf("%.2lf\n", task11());
    printf("%s\n", task12());
    printf("%s\n", task13());
    task14();
    printf("%s\n",task15());
    task16("wiadomosc");

    return 0;
}

/*
16. Szyfrowanie i deszyfrowanie kodem Cezara dla zadanej odległości liter w alfabecie.
'z' - 'a' + 1
*/
