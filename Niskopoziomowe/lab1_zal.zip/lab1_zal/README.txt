Ze względu na to, że otrzymywałem błędy podczas kompilacji próbując użyć typu bool (unknown type name bool),
uzyłem typu int.
